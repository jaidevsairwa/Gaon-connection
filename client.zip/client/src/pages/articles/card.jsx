import React, { useState } from "react";
import './maker.css'
import { useNavigate } from "react-router-dom";

const Card = (props) => {
		return (

		<>

		</>
		
	);
};
export default Card;