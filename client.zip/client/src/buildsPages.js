export const buildPages = [
    "/",
    "/aboutus",
    "/radio",
    "/story",
    '/gaon-tv',
    '/gaon-broadcast',
    '/gaon-audio',
    'blogs',
    'gardening',
    'daily-file',
    'social-life',
    'changeMaker'
  ];
  