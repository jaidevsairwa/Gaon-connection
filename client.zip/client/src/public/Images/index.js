export { default as LifeOne } from "../../assets/Images/life_one.png";
export { default as LifeTwo } from "../../assets/Images/life_two.png";
export { default as LifeThree } from "../../assets/Images/life_three.png";
export { default as Solar_Help } from "../../assets/Images/solar_helping.png";
export { default as SolarThree } from "../../assets/Images/solar_three.png";
export { default as SolarTwo } from "../../assets/Images/solar_two.png";
export { default as SolarOne } from "../../assets/Images/solar_one.png";
export { default as SolarHelp } from "../../assets/Images/solar_help.png";
export { default as Garden } from "../../assets/Images/Garden.png";
export { default as SolarBuzz } from "../../assets/Images/solarbuzz_one.png";
export { default as SolarBuzz1 } from "../../assets/Images/solarbuzz_two.png";
export { default as SolarBuzz2 } from "../../assets/Images/solarbuzz_three.png";
export { default as ImageCard1 } from "../../assets/Images/ImageCard1.png";
export { default as ImageCard2 } from "../../assets/Images/ImageCard2.png";
export { default as GridImage } from "../../assets/Images/grid-image.png";
export { default as GridImage1 } from "../../assets/Images/grid-image1.png";
export { default as GridImage2 } from "../../assets/Images/grid-image2.png";
export { default as GridImage3 } from "../../assets/Images/grid-image3.png";
export { default as Banner } from "../../assets/Images/banner.png";
// export { default as Radio } from "../../assets/Images/radio.jpg";
export { default as Banner_one } from "../../assets/insights.png"
export { default as Logo } from "../../assets/icons/footer-logo.svg"

export { default as TV } from "../../assets/Images/Gaon_tv.jpeg"
export { default as Radio } from "../../assets/Images/Gaon_radio.jpeg"
export { default as Broadcast } from "../../assets/Images/Gaon_broadcast.jpeg"

// export { default as jai } from "../../assets/images/jai.png"